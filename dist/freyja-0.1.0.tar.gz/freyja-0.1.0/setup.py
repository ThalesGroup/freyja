# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['freyja',
 'freyja.cli',
 'freyja.core',
 'freyja.core.handlers',
 'freyja.core.provisioning',
 'freyja.core.services',
 'freyja.lib',
 'freyja.lib.exceptions',
 'freyja.lib.utils',
 'freyja.models',
 'freyja.tests',
 'freyja.tests.cli',
 'freyja.tests.lib',
 'freyja.tests.lib.utils']

package_data = \
{'': ['*'], 'freyja': ['templates/*'], 'freyja.tests': ['resources/*']}

install_requires = \
['Jinja2>=3.0.3,<4.0.0',
 'PyYAML>=6.0,<7.0',
 'pydantic>=1.9.0,<2.0.0',
 'pytest-cov>=3.0.0,<4.0.0',
 'pytest-dotenv>=0.5.2,<0.6.0',
 'pytest>=7.0.1,<8.0.0',
 'python-dotenv>=0.19.2,<0.20.0',
 'typer>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['freyja = freyja.__main__:main']}

setup_kwargs = {
    'name': 'freyja',
    'version': '0.1.0',
    'description': 'VM management utility tool',
    'long_description': None,
    'author': 'kaio',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
