import logging

import typer

from freyja.core.services.machine_service import restore_snapshot, create_snapshot, list_snapshot
from freyja.lib.utils.subprocess_utils import yes_no_question
from freyja.logger import FreyjaLogger

app = typer.Typer(help="Manage snapshots of virtual machines")

logger: logging.Logger = logging.getLogger(FreyjaLogger.name)


@app.command()
def restore(name: str = typer.Argument(..., help="VM name to restore"),
            snapshot: str = typer.Argument(..., help="Name of the snapshot")):
    """
    Restore a VM from a snapshot
    """
    restore_snapshot(name, snapshot)
    logger.warning(f"The machine {name} will be restore to snapshot {snapshot}")
    if yes_no_question("Are you sure ? (Y/n)[default: n]", False):
        restore_snapshot(name, snapshot)
        logger.info("OK")
    else:
        logger.info("Aborted")


@app.command()
def snapshot(name: str = typer.Argument(..., help="VM name to snapshot"),
             snapshot: str = typer.Argument(..., help="Name of the snapshot")):
    """
    Create a snapshot of a VM
    """
    create_snapshot(name, snapshot)


@app.command()
def list_(name: str = typer.Argument(..., help="List the snapshots of a VM")):
    """
    List snapshots of a VM
    """
    list_snapshot(name)
